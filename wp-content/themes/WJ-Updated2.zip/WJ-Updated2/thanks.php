<?php get_header(); ?>
<p>Thanks</p>