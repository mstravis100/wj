<div class="paper-bg">
	<div class="pattern pie">
		<object data="<?php echo get_template_directory_uri(); ?>/library/img/eat-more-pie.min.svg" type="image/svg+xml" alt="Eat More Pie" class="eat-pie">
			 <img src="<?php echo get_template_directory_uri(); ?>/library/img/eat-more-pie.png" alt="Eat More Pie" class="eat-pie" />
		</object>

		<img src="<?php echo get_template_directory_uri(); ?>/library/img/Bird_Animated.gif" alt="Pie bird" class="pie-bird" />
	</div>
</div>
